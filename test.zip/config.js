
export const TELEGRAM_BOT_TOKEN = ''; // bot telegram token

export const REDIRECT_BOT = "None" // a redirect bot when the bot is full

export const OWNER_ID = "" // owner id

export const LIMIT = 30; //number of max sessions for the tele bot

export const MODE = "Default";


